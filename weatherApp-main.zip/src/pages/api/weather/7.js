export default function handler(req, res) {
  let WeatherInfo = [];

  for (let i = 1; i < 8; i++) {
    const today = new Date();
    today.setDate(today.getDate() + i);
    const date = `${today.getFullYear()}-${today.getMonth() + 1}-${today.getDate()}`;
    console.log(date)
    const url = `http://api.weatherapi.com/v1/forecast.json?key=${process.env.API_KEY}&q=Samara&dt=${date}&lang=ru`;

    fetch(url).then(response => response.json())
    .then(data =>  WeatherInfo.push(data));
    console.log(WeatherInfo)
  }

  res.status(200).json(WeatherInfo);
}
