//Main components
import WeatherLayout from "@/layouts/Weather";
import Navbar from "@/components/main/navbar";
import Footer from "@/components/main/footer";
import FixedPlugin from "@/components/main/fixed_plugin";
//Import weather Components



const Weather = () => {
    return (
        <WeatherLayout>
            <Navbar />
            <FixedPlugin />
        </WeatherLayout>
    );
};

export default Weather;
