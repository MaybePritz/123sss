import { useEffect } from "react";

import { useRouter } from 'next/router'

import classNames from "classnames";

import { useAppController } from "@/context";

const WeatherLayout = ({ children }) => {
    const [controller, dispatch] = useAppController();
    const { sidebarStatus } = controller;
    const { pathname } = useRouter();


    return (
        <div className={classNames(
            'ease-soft-in-out',
            { 'xl:ml-68.5': sidebarStatus },
            'relative',
            'h-full',
            'max-h-screen',
            'rounded-xl',
            'transition-all',
            'duration-200',
            'overflow-x-hidden')}>
            {children}
        </div>
    );
}

export default WeatherLayout;
