import { useState, useEffect } from "react";
import infoSquare from "../ui/infoSquare";

export default function Forecast() {
  const [weather, setWeather] = useState(null);
  const [weatherDate, setWeatherDate] = useState(null);
  const [isLoading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true);
    fetch("../api/forecast")
      .then((res) => res.json())
      .then((weather) => {
        setWeather(weather);
        setWeatherDate(new Date(Number(weather.current.last_updated_epoch) * 1000));
        setLoading(false);
      });
  }, []);
  
  if (isLoading)
    return (
      <div role="status">
        <svg
          aria-hidden="true"
          class="w-8 h-8 mr-2 text-gray-200 animate-spin dark:text-gray-600 fill-blue-600"
          viewBox="0 0 100 101"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z"
            fill="currentColor"
          />
          <path
            d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z"
            fill="currentFill"
          />
        </svg>
        <span class="sr-only">Loading...</span>
      </div>
    );
  if (!weather) return <p>No weather data</p>;


  switch (weather.current.condition.code) {
    case 1000:
      var weather_2d_icon = "ph-fill ph-sun ";
      var weather_3d_icon = "sun";
      if (weather.current.is_day == "0") {
        var weather_2d_icon = "ph-fill ph-moon-stars";
        var weather_3d_icon = "moon-stars";
      }
      break;
    case 1003:
      var weather_2d_icon = "ph-fill ph-cloud-sun";
      var weather_3d_icon = "cloud-sun";
      if (weather.current.is_day == "0") {
        var weather_2d_icon = "ph-fill ph-cloud-moon";
        var weather_3d_icon = "cloud-moon";
      }
      break;
    case 1006:
    case 1009:
      var weather_2d_icon = "ph-fill ph-cloud";
      var weather_3d_icon = "cloud";
      break;
    case 1030:
    case 1135:
    case 1147:
      var weather_2d_icon = "ph-fill ph-cloud-fog";
      var weather_3d_icon = "sun-cloud-fog";
      if (weather.current.is_day == "0") {
        var weather_3d_icon = "moon-cloud-fog";
      }
      break;
    case 1063:
    case 1072:
    case 1150:
    case 1153:
    case 1168:
    case 1171:
    case 1180:
    case 1183:
    case 1186:
    case 1189:
    case 1192:
    case 1195:
    case 1198:
    case 1201:
      var weather_2d_icon = "ph-fill ph-cloud-rain";
      var weather_3d_icon = "cloud-rain";
      break;
    case 1066:
    case 1069:
    case 1204:
    case 1207:
    case 1210:
    case 1213:
    case 1216:
    case 1222:
    case 1237:
    case 1240:
    case 1243:
    case 1246:
    case 1249:
    case 1252:
    case 1255:
    case 1261:
    case 1264:
      var weather_2d_icon = "ph-fill ph-cloud-snow";
      var weather_3d_icon = "cloud-snow";
      break;
    case 1087:
    case 1273:
    case 1276:
    case 1279:
    case 1282:
      var weather_2d_icon = "ph-fill ph-lightning";
      var weather_3d_icon = "lightning";
      break;
    case 1114:
    case 1117:
      var weather_2d_icon = "ph-fill ph-wind";
      var weather_3d_icon = "sun-wind";
      if (weather.current.is_day == 0) {
        var weather_3d_icon = "moon-wind";
      }
      break;
    default:
      var weather_2d_icon = "ph-fill ph-question";
  }

  return (
    <>
      <div className="lg:w-4/12 px-3 mt-6 lg:mb-0 lg:flex-none">
        <div className="relative h-full flex flex-col min-w-0 break-words bg-white rounded-3xl bg-clip-border">
          <div className="flex-auto p-4">
            <div className="flex flex-wrap -mx-3">
              <div className="max-w-full px-3 lg:flex-none">
                <div className="flex flex-col h-full">
                  <p className="pt-2 mb-4 font-semibold">
                    Погода на {" "}
                    {weatherDate.getHours() + ":" + (weatherDate.getMinutes()<10 ? '0' : '') + weatherDate.getMinutes()}
                  </p>
                  <h5 className="font-bold text-7xl my-4">
                    {weather.current.temp_c}&#176;
                  </h5>
                  <div className="mb-0  flex items-center group">
                    <i
                      className={`${weather_2d_icon} text-3xl group-hover:scale-110 ease-bounce leading-normal transition-all duration-200 mr-2`}
                    ></i>
                    <p className="text-lg font-medium m-0">
                      {weather.current.condition.text}
                    </p>
                  </div>
                  <div class="w-full mx-auto mt-auto rounded-xl">
                    <div class="flex flex-wrap mt-0">
                      <div class="flex-none w-1/3 max-w-full py-4 pl-0 pr-3 mt-0">
                        <div class="flex mb-2">
                          <div class="flex items-center justify-center w-6 h-6 mr-2 text-center bg-center rounded  shadow-soft-2xl bg-gradient-to-tl from-[#1D976C] to-[#93F9B9]">
                            <i class="ph-fill ph-thermometer-hot text-white"></i>
                          </div>
                          <p class="mt-1 mb-0 font-semibold leading-tight text-xs">
                            Макс. Темп
                          </p>
                        </div>
                        <h4 class="font-bold">{weather.forecast.forecastday[0].day.maxtemp_c}&#176;</h4>
                        <div class="text-xs h-0.75 flex w-3/4 overflow-visible rounded-lg bg-gray-200">
                          <div
                            class="duration-600 ease-soft -mt-0.4 -ml-px flex h-1.5 w-9/10 flex-col justify-center overflow-hidden whitespace-nowrap rounded-lg bg-slate-700 text-center text-white transition-all"
                            role="progressbar"
                            aria-valuenow="60"
                            aria-valuemin="0"
                            aria-valuemax="100"
                          ></div>
                        </div>
                      </div>
                      <div class="flex-none w-1/3 max-w-full py-4 pl-0 pr-3 mt-0">
                        <div class="flex mb-2">
                          <div class="flex items-center justify-center w-6 h-6 mr-2 text-center bg-center rounded  shadow-soft-2xl bg-gradient-to-tl from-[#1D976C] to-[#93F9B9]">
                            <i class="ph-fill ph-thermometer-cold text-white"></i>
                          </div>
                          <p class="mt-1 mb-0 font-semibold leading-tight text-xs">
                            Мин. Темп
                          </p>
                        </div>
                        <h4 class="font-bold ">{weather.forecast.forecastday[0].day.mintemp_c}&#176;</h4>
                        <div class="text-xs h-0.75 flex w-3/4 overflow-visible rounded-lg bg-gray-200">
                          <div
                            class="duration-600 ease-soft -mt-0.4 w-3/10 -ml-px flex h-1.5 flex-col justify-center overflow-hidden whitespace-nowrap rounded-lg bg-slate-700 text-center text-white transition-all"
                            role="progressbar"
                            aria-valuenow="90"
                            aria-valuemin="0"
                            aria-valuemax="100"
                          ></div>
                        </div>
                      </div>
                      <div class="flex-none w-1/3 max-w-full py-4 pl-0 pr-3 mt-0">
                        <div class="flex mb-2">
                          <div class="flex items-center justify-center w-6 h-6 mr-2 text-center bg-center rounded  shadow-soft-2xl bg-gradient-to-tl from-[#1D976C] to-[#93F9B9]">
                            <i class="ph-fill ph-ruler text-white"></i>
                          </div>
                          <p class="mt-1 mb-0 font-semibold leading-tight text-xs">
                            Давление
                          </p>
                        </div>
                        <h4 class="font-bold">{Math.round(weather.current.pressure_mb / 1.333)} мм </h4>
                        <div class="text-xs h-0.75 flex w-3/4 overflow-visible rounded-lg bg-gray-200">
                          <div
                            class="duration-600 ease-soft -mt-0.4 w-1/2 -ml-px flex h-1.5 flex-col justify-center overflow-hidden whitespace-nowrap rounded-lg bg-slate-700 text-center text-white transition-all"
                            role="progressbar"
                            aria-valuenow="30"
                            aria-valuemin="0"
                            aria-valuemax="100"
                          ></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
